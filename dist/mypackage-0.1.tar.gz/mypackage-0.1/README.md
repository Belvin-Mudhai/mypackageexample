# mypackage
This library was created to demonstrate how to create your own package in python.

# How to install
To install this pacakge, just don't man! It's an example.